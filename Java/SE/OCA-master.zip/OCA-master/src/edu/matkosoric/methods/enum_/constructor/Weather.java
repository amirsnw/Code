package edu.matkosoric.methods.enum_.constructor;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public enum Weather {

//    SUNNY(1),
//    RAIN(2),
//    SNOW(3);
//
//    final int weatherCode;
//
//    // enum constructor
//    public Weather (int code) {     // does not compile
//        this.weatherCode = code;
//    }

}
