package edu.matkosoric.inheritance.linking.constructors;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Core {

    public Core() {}

    public Core (int x) {  }

//    public Core (int x, int y) {     }  // can be commented out, since it is not
//                                        // explicitly called from the child class

}
