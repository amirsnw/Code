package edu.matkosoric.polymorphism.overriding.member.states.regions;

import edu.matkosoric.polymorphism.overriding.member.states.Spain;

/**
 * Created by matko on 31.7.2017..
 */
public class Catalonia extends Spain{

    Spain es = new Spain();

    {officialLanguage = "Catalan";
    capitalCity = "Barcelona";
//        sanFerminLocation = "";
//        GDP_per_capita = 0;
    }

}
