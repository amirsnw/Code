package edu.matkosoric.methods.if_.within.print;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class IfWithinPrintln {

    public static void main(String[] args) {

        // if else condition can not be placed within a println method
        // this will not compile

        /*
        System.out.println( if (true== true) {
                                System.out.println("Hello");
                                }
                            else {
                                System.out.println("Bye"));
                             }
        */

    }

}
