package edu.matkosoric.inheritance.inheriting.variables;
/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Monkey {

    boolean manners = false;
    static int iq = 60;

}
