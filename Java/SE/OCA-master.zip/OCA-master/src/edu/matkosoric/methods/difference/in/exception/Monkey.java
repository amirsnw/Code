package edu.matkosoric.methods.difference.in.exception;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Monkey {

    public void eating () throws Exception {
        System.out.println("raw food");
    }

}
