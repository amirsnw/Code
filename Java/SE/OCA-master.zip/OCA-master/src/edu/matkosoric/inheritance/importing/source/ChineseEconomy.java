package edu.matkosoric.inheritance.importing.source;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class ChineseEconomy {

    // static methods
    public static void cars (){
        System.out.println("Chinese cars.");
    }
    public static void TVs () {
        System.out.println("Chinese TVs.");
    }
    public static void ships () {
        System.out.println("Chinese ships.");
    }
}
