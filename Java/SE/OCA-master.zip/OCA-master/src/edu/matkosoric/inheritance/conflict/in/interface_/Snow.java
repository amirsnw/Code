package edu.matkosoric.inheritance.conflict.in.interface_;
/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public interface Snow {

    void badWeather();

    double amountOf = 4;

}
