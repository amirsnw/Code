package edu.matkosoric.inheritance.constructing.super_;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class KingArthur {

    public static void main(String[] args) {

        SwordPerSe a = new Excalibur("Excalibur");
        System.out.println(a.getSwordName());

    }
}
