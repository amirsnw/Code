package edu.matkosoric.inheritance.hiding.variables;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class InvisibilityPerSe {

    static int releaseYear1 = 0;
    static int releaseYear2 = 0;
    static int releaseYear3 = 0;

    static String name1 = "First actor";
    static String name2 = "Second actor";
    static String name3 = "Third actor";

    String summary1 = "1. Parent summary: Adventures of the invisible man.";
    String summary2 = "2. Parent summary: Adventures of the invisible man.";

}
