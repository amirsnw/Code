package entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
