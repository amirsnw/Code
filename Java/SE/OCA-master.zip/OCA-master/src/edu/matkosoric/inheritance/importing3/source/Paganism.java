package edu.matkosoric.inheritance.importing3.source;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Paganism {

    public static void celebratingSaturnalia () {
        System.out.println("static saturnalia");
    }

    public void otherCustoms () {
        System.out.println("instance custom");
    }

}
