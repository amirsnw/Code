package edu.matkosoric.inheritance.interface_.inheritance;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

// interface can not implement another interface.
// interface can extend another interface.

//public interface AnimalLife implements Life{ }        // does not compile

public interface AnimalLife {}
