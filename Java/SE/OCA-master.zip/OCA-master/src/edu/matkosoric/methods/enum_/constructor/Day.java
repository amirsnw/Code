package edu.matkosoric.methods.enum_.constructor;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Day {

    // enum constructor can not be public or protected

    public static void main(String[] args) {

//        Weather a = Weather.SNOW;

    }

}
