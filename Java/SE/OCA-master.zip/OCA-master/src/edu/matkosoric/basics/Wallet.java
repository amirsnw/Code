package edu.matkosoric.basics;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Wallet {

    // string array from main arguments is never null, even when there is no arguments

    public static void main(String[] args) {

        System.out.println( args.length);       // not null

    }
}
