package edu.matkosoric.flowcontrol.static_;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Green extends Blue {

    // static initializer
    static {
        System.out.println("Green.class loading...");
    }

}
