package edu.matkosoric.methods.covariant.return_.covariant.return_.types;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

import edu.matkosoric.methods.covariant.return_.HardDrugs;

// covariant return type
public class Methamphetamine extends HardDrugs {
    String substanceName = "Methamphetamine";
}
