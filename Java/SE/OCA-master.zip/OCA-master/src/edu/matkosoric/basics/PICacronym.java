//import edu.matkosoric.basics.Milk;

package edu.matkosoric.basics;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class PICacronym {

    // if first line is not commented out,
    // the code will not compile.
    // proper order is package - import - class (PIC)

}
