package entity;

public enum Color {

    BLACK, RED, GREY

}
