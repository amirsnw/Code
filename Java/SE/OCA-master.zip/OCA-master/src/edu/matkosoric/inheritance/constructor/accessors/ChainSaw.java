package edu.matkosoric.inheritance.constructor.accessors;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class ChainSaw extends Saw{   }
