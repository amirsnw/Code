package edu.matkosoric.inheritance.casting2;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class CardiovascularDisease extends Programming{

    public static void main(String[] args) {

        Programming myJob = new Programming();

//        CardiovascularDisease myDisease = (CardiovascularDisease) myJob;        // compiles, but throws ClassCastException

    }
}
