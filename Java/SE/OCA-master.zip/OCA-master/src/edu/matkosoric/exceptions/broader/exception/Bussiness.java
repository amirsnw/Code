package edu.matkosoric.exceptions.broader.exception;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Bussiness extends Marketing {

    // overriding method can throw >wider< exceptions than original, overridden method

    public void initiateCampaign() throws NumberFormatException {

    }

}
