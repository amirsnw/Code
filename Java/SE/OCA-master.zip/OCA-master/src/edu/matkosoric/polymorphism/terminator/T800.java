package edu.matkosoric.polymorphism.terminator;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class T800 {

    public static void findJohnConnor () {
        System.out.println("T-800 ... searching for John Connor...");
    }

}
