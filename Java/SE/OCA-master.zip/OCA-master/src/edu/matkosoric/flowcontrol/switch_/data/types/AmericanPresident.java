package edu.matkosoric.flowcontrol.switch_.data.types;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class AmericanPresident {

    int ordinalNumber;
    String name;
    String surname;

    public AmericanPresident(int ordinalNumber, String name, String surname) {
        this.ordinalNumber = ordinalNumber;
        this.name = name;
        this.surname = surname;
    }
}
