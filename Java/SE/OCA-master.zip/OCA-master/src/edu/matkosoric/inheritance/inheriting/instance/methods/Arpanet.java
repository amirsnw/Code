package edu.matkosoric.inheritance.inheriting.instance.methods;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Arpanet {

    public void utilisation () {
        System.out.println("military");
    }

    public static void printName () {
        System.out.println("Arpanet");
    }

}
