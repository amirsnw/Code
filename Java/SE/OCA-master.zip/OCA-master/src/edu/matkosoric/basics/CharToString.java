package edu.matkosoric.basics;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class CharToString {

    public static void main(String[] args) {

        // string literals are enclosed with double quotes " ",
        // while char literals have single quotes ' '.
        char celsius = 'c';
//        String fahrenheit = 'f';      // does not compile
//        char kelvin = "k";              // does not compile

    }
}
