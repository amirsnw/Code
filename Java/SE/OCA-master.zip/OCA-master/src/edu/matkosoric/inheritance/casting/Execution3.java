package edu.matkosoric.inheritance.casting;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

import edu.matkosoric.inheritance.casting.data.types.Asia;
import edu.matkosoric.inheritance.casting.data.types.EuroAsia;
import edu.matkosoric.inheritance.casting.data.types.Pangaea;

public class Execution3 {


    public static void main(String[] args) {

        Pangaea a = new Pangaea();

        Pangaea d1 = new Asia();
        EuroAsia d2 = new Asia();
        Asia d3 = new Asia();




    }
}
