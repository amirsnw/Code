package edu.matkosoric.inheritance.importing2.river;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class River {

    // constructor with default access
    River () {}

}
