package edu.matkosoric.polymorphism.instanceof_;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Golf {

    // class Golf is not related through inheritance with TV or Radio,
    // not does it implement Sound interface.
    // they only share the same package.

}
