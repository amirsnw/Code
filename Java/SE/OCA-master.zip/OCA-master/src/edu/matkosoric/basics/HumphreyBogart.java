package edu.matkosoric.basics;
/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class HumphreyBogart {

    // 'for' is java keyword and can not be used as a label
    // on the other hand, 'FOR' is not a java keyword and can be used instead

    public static void main(String[] args) {

        char [] myFavoriteActorName = new char[] {'h','u','m','p','h','r','e','y'};

//        for:         for (char c : myFavoriteActorName) {
//                        System.out.print(c);
//                        if (c == 'p') break for;
//                        }

    }

}
