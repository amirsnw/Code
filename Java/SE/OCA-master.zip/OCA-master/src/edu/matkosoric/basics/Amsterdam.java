package edu.matkosoric.basics;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

public class Amsterdam {

    // the if statement will not compile due to the almost unnoticeable and redundant ; sign that represents valid Java statement

    public static void main(String[] args) {

        String driver = "Jules";

//        if (driver == "Jules");
//            System.out.println("Jules is driving.");
//        else if (driver == "Vincent")
//            System.out.println("Vincent is driving.");


    }

}
