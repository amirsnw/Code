package edu.matkosoric.methods.covariant.return_;

/*
 * Code examples for Oracle Certified Associate (OCA) Exam
 * Java 8 SE, 2017.
 * Created by © Matko Soric.
 */

 // top class
public class HardDrugs {
    String substanceName = "illegal substance";
    double weight = 0.0;
}
